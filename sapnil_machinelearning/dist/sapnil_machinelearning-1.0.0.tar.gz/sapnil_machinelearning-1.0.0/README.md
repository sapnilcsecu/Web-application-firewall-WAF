<h1><span style="font-family:Times New Roman,Times,serif"><strong><a href="https://github.com/sapnilcsecu/sapnil_machinelearning"><span style="color:#000000"><span style="font-size:large"><u><strong>Sapnil machine learning</strong></u></span></span></a></strong></span></h1>

<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000">This is machine learning tools for textmining. Present it support only supervised machine learning for text classification.</span></span></p>

<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000"><span style="font-size:large"><u><strong>Release</strong></u></span><span style="font-size:large"><u> </u></span> </span></span></p>

<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000"><strong>Release 1.0:</strong></span></span></p>

<ul>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000">in release 1.0 support supervised machine learning for text classification with the multinomial native bayes algorithom.</span></span></p>
	</li>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000">It support only CVS file as a structured input data for supervised machine learning.</span></span></p>
	</li>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000">It support only <span style="font-size:12px">CountVectorizer</span><strong><span style="color:#000000"><span style="font-size:medium"> </span></span></strong>feature engineering.</span><span style="font-size:12px"><span style="color:#000000">CountVectorizer works on Terms Frequency, i.e. counting the occurrences of tokens and building a sparse matrix of documents x tokens.</span></span></span></p>
	</li>
</ul>

<p>&nbsp;</p>

<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000"><strong><span style="font-size:large"><u>Installation :</u></span></strong></span></span></p>

<h4><span style="font-family:Times New Roman,Times,serif"><strong><span style="color:#000000"><span style="font-size:medium">Dependencies:</span></span></strong></span></h4>

<h4><span style="font-family:Times New Roman,Times,serif"><span style="color:#464646"><span style="font-size:medium"><span style="color:#000000">Sapnil machine learning require :</span></span></span></span></h4>

<ul>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><strong><span style="color:#000000"><span style="font-size:medium">Pandas(&gt;=0.24</span></span></strong><strong><span style="color:#000000"><span style="font-size:medium">)</span></span></strong></span></p>
	</li>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><strong><span style="color:#000000"><span style="font-size:medium">numpy(&gt;=</span></span></strong><strong><a href="https://github.com/numpy/numpy/releases/tag/v1.16.5"><span style="color:#000000"><span style="font-size:medium">1.16.5</span></span></a></strong><strong><span style="color:#000000"><span style="font-size:medium"> )</span></span></strong></span></p>
	</li>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><strong><span style="color:#000000"><span style="font-size:medium">nltk(&gt;=3.4.1 )</span></span></strong></span></p>
	</li>
</ul>

<h4><span style="font-family:Times New Roman,Times,serif"><u><strong><span style="color:#000000"><span style="font-size:medium">User installation:</span></span></strong></u></span></h4>

<p><span style="color:#000000"><span style="font-family:Times New Roman,serif"><span style="font-size:medium"><u><strong>Windows installation</strong></u></span></span></span></p>

<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000"><span style="font-size:medium">After cloning reprository go to sapnil_machinelearning folder from commad line.Then press the following commad from commad prompt </span></span></span></p>

<ul>
	<li>
	<p><span style="font-family:Times New Roman,Times,serif"><span style="color:#000000"><span style="font-size:medium">pip install dist/dokr-0.1-py3-none-any.whl</span></span></span></p>
	</li>
</ul>

<p>&nbsp;</p>
